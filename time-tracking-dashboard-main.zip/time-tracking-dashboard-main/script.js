const btnDaily = document.querySelector(".btn-daily");
const btnWeekly = document.querySelector(".btn-weekly");
const btnMonthly = document.querySelector(".btn-monthly");
const work = document.querySelector(".work");
const play = document.querySelector(".play");
const study = document.querySelector(".study");
const exercise = document.querySelector(".exercise");
const social = document.querySelector(".social");
const selfCare = document.querySelector(".self-care");

// Daily
btnDaily.addEventListener("click", async (e) => {
  const response = await fetch("/data.json");
  const users = await response.json();

  users.forEach((category) => {
    const title = category.title;
    const timeframes = category.timeframes;
    const dailyCurrent = timeframes.daily.current;
    const dailyPrevious = timeframes.daily.previous;

    if (title === "Work") {
      const workMessage = `${dailyCurrent} hrs 
      Last Week ${dailyPrevious} hrs`;
      work.append(workMessage);
    }
    if (title === "Play") {
      const playMessage = `${dailyCurrent} hrs 
      Last Week ${dailyPrevious} hrs`;
      play.append(playMessage);
    }
    if (title === "Study") {
      const studyMessage = `${dailyCurrent} hrs 
      Last Week ${dailyPrevious} hrs`;
      study.append(studyMessage);
    }
    if (title === "Exercise") {
      const exerciseMessage = `${dailyCurrent} hrs 
      Last Week ${dailyPrevious} hrs`;
      exercise.append(exerciseMessage);
    }
    if (title === "Social") {
      const socialMessage = `${dailyCurrent} hrs 
      Last Week ${dailyPrevious} hrs`;
      social.append(socialMessage);
    }
    if (title === "Self Care") {
      const selfCareMessage = `${dailyCurrent} hrs 
      Last Week ${dailyPrevious} hrs`;
      selfCare.append(selfCareMessage);
    }
  });
});

// Weekly
btnWeekly.addEventListener("click", async (e) => {
  const response = await fetch("/data.json");
  const users = await response.json();

  users.forEach((category) => {
    const title = category.title;
    const timeframes = category.timeframes;
    const weeklyCurrent = timeframes.weekly.current;
    const weeklyPrevious = timeframes.weekly.previous;

    if (title === "Work") {
      const workMessage = `${weeklyCurrent} hrs 
      Last Week ${weeklyPrevious} hrs`;
      work.append(workMessage);
    }
    if (title === "Play") {
      const playMessage = `${weeklyCurrent} hrs 
      Last Week ${weeklyPrevious} hrs`;
      play.append(playMessage);
    }
    if (title === "Study") {
      const studyMessage = `${weeklyCurrent} hrs 
      Last Week ${weeklyPrevious} hrs`;
      study.append(studyMessage);
    }
    if (title === "Exercise") {
      const exerciseMessage = `${weeklyCurrent} hrs 
      Last Week ${weeklyPrevious} hrs`;
      exercise.append(exerciseMessage);
    }
    if (title === "Social") {
      const socialMessage = `${weeklyCurrent} hrs 
      Last Week ${weeklyPrevious} hrs`;
      social.append(socialMessage);
    }
    if (title === "Self Care") {
      const selfCareMessage = `${weeklyCurrent} hrs 
      Last Week ${weeklyPrevious} hrs`;
      selfCare.append(selfCareMessage);
    }
  });
});
btnMonthly.addEventListener("click", async (e) => {
  const response = await fetch("/data.json");
  const users = await response.json();

  users.forEach((category) => {
    const title = category.title;
    const timeframes = category.timeframes;
    const monthlyCurrent = timeframes.monthly.current;
    const monthlyPrevious = timeframes.monthly.previous;

    if (title === "Work") {
      const workMessage = `${monthlyCurrent} hrs 
      Last Week ${monthlyPrevious} hrs`;
      work.append(workMessage);
    }
    if (title === "Play") {
      const playMessage = `${monthlyCurrent} hrs 
      Last Week ${monthlyPrevious} hrs`;
      play.append(playMessage);
    }
    if (title === "Study") {
      const studyMessage = `${monthlyCurrent} hrs 
      Last Week ${monthlyPrevious} hrs`;
      study.append(studyMessage);
    }
    if (title === "Exercise") {
      const exerciseMessage = `${monthlyCurrent} hrs 
      Last Week ${monthlyPrevious} hrs`;
      exercise.append(exerciseMessage);
    }
    if (title === "Social") {
      const socialMessage = `${monthlyCurrent} hrs 
      Last Week ${monthlyPrevious} hrs`;
      social.append(socialMessage);
    }
    if (title === "Self Care") {
      const selfCareMessage = `${monthlyCurrent} hrs 
      Last Week ${monthlyPrevious} hrs`;
      selfCare.append(selfCareMessage);
    }
  });
});
